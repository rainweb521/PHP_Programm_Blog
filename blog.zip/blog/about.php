<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">

<html>
<head>
<title>Rain_Blog</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="style.css" rel="stylesheet" type="text/css" />
<!-- CuFon: Enables smooth pretty custom font rendering. 100% SEO friendly. To disable, remove this section -->
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cuf_run.js"></script>
<link href="css/style2.css" rel="stylesheet">
<link href="css/media.css" rel="stylesheet">
<!-- CuFon ends -->
</head>
<body>
<div class="main"><?php include 'menu/head.php'?> <br>
<br>
<br>
<br>
<div class="content">
<div class="content_resize">
<div class="mainbar">

<div class="ibody"><article>
<div class="index_about">
<h2 class="c_titile">个人简介</h2>
<ul class="infos">
<h3>Just about me</h3>
   <ul> 
   
    

</p>
    </ul>
    <h3>About my blog</h3>
    <p>域  名：www.rainweb.site 创建于2017年01月20日 </p>
    <p>服务器：Centos6.5 + mysql5.6 + php5 发布于网易蜂巢</p>
    <p>程  序：PHP</p>
</ul>
</ul>
</div>
</article></div>

</div>
<div class="sidebar">
<div class="searchform">
<form id="formsearch" name="formsearch" method="post" action=""><span><input
	name="editbox_search" class="editbox_search" id="editbox_search"
	maxlength="80" value="Search our ste:" type="text" /></span> <input
	name="button_search" src="images/search_btn.gif" class="button_search"
	type="image" /></form>
</div>
<div class="gadget">
<h2 class="star"><span>Blog_</span> Menu</h2>
<div class="clr"></div>
<ul class="sb_menu">
<?php include 'menu/head2.php'?>
</ul>
</div>
<div class="gadget">
<h2 class="star"><span>Introduce</span></h2>
<div class="clr"></div>
<ul class="ex_menu">
<?php include 'menu/professional_menu.php'?>
</ul>
</div>
</div>
<div class="clr"></div>
</div>
</div>

<?php include 'menu/foot.php'?></div>
</body>
</html>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Insert title here</title>
</head>
<body>
<div class="header">
    <div class="header_resize">
      <div class="menu_nav">
        <ul>
          <li class="active"><a href="../index.php">博客首页</a></li>
          <li><a href="../article_show_List.php">文章</a></li>
          <li><a href="../diary.php">随记</a></li>
          <li><a href="../photo_show_Name.php">相册</a></li>
          <li><a href="../show_Message.php">留言板</a></li>
          <li><a href="../about.php">关于我</a></li>
          <li><a href="../more.php">更多功能</a></li>
        </ul>
      </div>
      <div class="clr"></div>
      <div class="logo"><h1><a href="/index.php"><span>Rain_Blog</span></a> <small>   </small></h1></div>
      <div class="clr"></div>
    </div>
  </div>
</body>
</html>






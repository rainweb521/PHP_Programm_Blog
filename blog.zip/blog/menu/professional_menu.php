<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Insert title here</title>
</head>
<body>
 <li>网站：<br>
	Rain_Blog&nbsp;&nbsp;&nbsp;&nbsp; <br />
	</li>
	<li>职业：<br />
	苦逼程序员</li>
	<li>技能：<br />
	PHP,Java,Python</li>
	<li>联系方式：<br />
	请点击下方我的主页</li>
</body>
</html>
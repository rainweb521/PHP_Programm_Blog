<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Insert title here</title>
</head>
<body>
<div class="fbg">
    <div class="fbg_resize">
      <div class="col c1">
        <h2><span>常用网站</span></h2>
        <a target="_blank" href="http://www.w3school.com.cn/index.html"><img src="/images/w3.jpg" width="58" height="58" alt="pix" /></a>
        <a target="_blank" href="http://www.icourse163.org/"><img src="/images/mooc.jpg" width="58" height="58" alt="pix" /></a>
        <a target="_blank" href="http://www.imooc.com/"><img src="/images/mw.jpg" width="58" height="58" alt="pix" /></a>
        <a target="_blank" href="https://github.com/"><img src="/images/github.jpg" width="58" height="58" alt="pix" /></a>
        <a target="_blank" href="http://www.csdn.net/"><img src="/images/csdn.jpg" width="58" height="58" alt="pix" /></a>
        <a target="_blank" href="https://www.nowcoder.com/"><img src="/images/nk.jpg" width="58" height="58" alt="pix" /></a>
      </div>
      <div class="col c3">
        <h2><span>语言工具</span></h2>
        <img src="/images/c.jpg" width="58" height="58" alt="pix" />
        <img src="/images/js.jpg" width="58" height="58" alt="pix" />
        <img src="/images/java.jpg" width="58" height="58" alt="pix" />
        <br>
        <img src="/images/python.jpg" width="58" height="58" alt="pix" />
        <img src="/images/php.jpg" width="58" height="58" alt="pix" />
        <img src="/images/mysql.jpg" width="58" height="58" alt="pix" />
     
      </div>
      <div class="col c3">
        <h2><span>我的主页</span></h2>
        <a target="_blank" href="http://weibo.com/5842719435/profile?topnav=1&wvr=6&is_all=1"><img src="/images/wb.jpg" width="58" height="58" alt="pix" /></a>
        <a target="_blank" href="https://www.zhihu.com/people/rain_web/activities"><img src="/images/zh.jpg" width="58" height="58" alt="pix" /></a>
        <a target="_blank" href="http://blog.csdn.net/rain_web"><img src="/images/csdn.jpg" width="58" height="58" alt="pix" /></a>
        <a target="_blank" href="https://note.wiz.cn/pages/manage/biz/applyInvited.html?code=lmrbxp"><img src="/images/wz.jpg" width="58" height="58" alt="pix" /></a>
        <a target="_blank" href="mailto:nylrain@163.com"><img src="/images/wy.jpg" width="58" height="58" alt="pix" /></a>
        <a target="_blank" href="mailto:641351484@qq.com"><img src="/images/qq.jpg" width="58" height="58" alt="pix" /></a>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div  align="center">
   @版权所有 ￥<a href="mailto:641351484@qq.com"> 联系我
  </div>
</body>
</html>
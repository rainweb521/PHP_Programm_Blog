## # PHP--Blog code
### 本项目使用php编写，前台功能基本完善，有顶部菜单和侧栏菜单底部菜单，支持首页展示功能，文章功能，文章包括列表显示和单篇文章显示功能，随记功能，以时间线展示，相册功能，每行会显示三张大小相同的照片，留言版功能，支持留言和已有留言的游览，还有About，包括扩展的更多功能，可登录后台，打赏作者，发送邮件功能（邮件可以发送），友情链接的显示，等待扩展功能，拥有后台结构编写完成，文章发布等功能还未添加，数据库sql文件已经放到config文件夹中

### 首页展示

<img src="http://blog-1252406596.costj.myqcloud.com/githubblog/blog1.png" width="1000" height="500"/>

### 文章列表

![](http://blog-1252406596.costj.myqcloud.com/githubblog/blog2.png)

### 具体文章显示

![](http://blog-1252406596.costj.myqcloud.com/githubblog/blog10.png)

### 随记列表显示

![](http://blog-1252406596.costj.myqcloud.com/githubblog/blog3.png)

### 相册列表显示

![](http://blog-1252406596.costj.myqcloud.com/githubblog/blog4.png)
### 留言版显示

![](http://blog-1252406596.costj.myqcloud.com/githubblog/blog5.png)
### 个人简介显示

![](http://blog-1252406596.costj.myqcloud.com/githubblog/blog6.png)
### 更多功能页面显示

![](http://blog-1252406596.costj.myqcloud.com/githubblog/blog7.png)
### 发送邮件功能页面显示

![](http://blog-1252406596.costj.myqcloud.com/githubblog/blog8.png)
### 底部菜单页面显示

![](http://blog-1252406596.costj.myqcloud.com/githubblog/blog9.png)